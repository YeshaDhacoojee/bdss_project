
import pandas as pd
import numpy as np
import random
from datetime import datetime

def generate_dataset():
    dates = pd.date_range(start="2023-01-01", end="2024-12-31", freq="D")
    stores = [f"S{i}" for i in range(1, 6)]
    products = [f"P{i}" for i in range(1, 21)]
    payment_methods = ["cash", "card", "mobile"]

    data = []
    transaction_id = 1

    for date in dates:
        daily_transactions = np.random.randint(50, 120)
        for _ in range(daily_transactions):
            product = random.choice(products)
            store = random.choice(stores)
            quantity = np.random.randint(1, 6)
            price = round(np.random.uniform(2.0, 50.0), 2)
            total = round(quantity * price, 2)

            payment = random.choice(payment_methods)
            device = f"D{random.randint(1, 200)}"
            ip = f"192.168.{random.randint(0,255)}.{random.randint(0,255)}"
            customer = f"C{random.randint(1, 500)}"

            data.append([
                transaction_id, product, store, quantity,
                price, total, payment, customer, device, ip, date
            ])
            transaction_id += 1

    df = pd.DataFrame(data, columns=[
        "transaction_id", "product_id", "store_id", "quantity",
        "price_per_unit", "total_amount", "payment_method",
        "customer_id", "device_id", "ip_address", "transaction_date"
    ])
    df.to_csv("daily_transactions.csv", index=False)

if __name__ == "__main__":
    generate_dataset()
